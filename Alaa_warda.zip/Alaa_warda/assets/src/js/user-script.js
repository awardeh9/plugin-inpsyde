(function ( $ ) {

	'use strict';

	console.info('Plugin user script loaded.');

})( jQuery );
